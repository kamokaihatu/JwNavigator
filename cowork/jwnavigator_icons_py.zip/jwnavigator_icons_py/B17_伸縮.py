"""
JwNavigator Icon Library

Icon : 伸縮
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_line(
        x+4,y+12, x+12,y+12,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+12,y+12, x+21,y+12,
        width=1, capstyle=tk.ROUND, dash=(1.2,1.8)
    )

    canvas.create_line(
        x+15,y+7, x+19,y+7,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+17,y+5, x+19,y+7, x+17,y+9,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )
