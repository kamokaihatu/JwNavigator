"""
JwNavigator Icon Library

Icon : 文字
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_line(
        x+12,y+3.5, x+4.5,y+20.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+12,y+3.5, x+19.5,y+20.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+7.75,y+13.5, x+16.25,y+13.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )
