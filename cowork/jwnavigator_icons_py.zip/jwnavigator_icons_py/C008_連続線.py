"""
JwNavigator Icon Library

Icon : 連続線
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_line(
        x+3,y+17, x+9,y+7, x+14,y+15, x+21,y+6,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )
