"""
JwNavigator Icon Library

Icon : 消去
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_rectangle(
        x+9.5, y+2.5, x+14.5, y+5,
        outline="black", width=1.7
    )

    canvas.create_line(
        x+4,y+6.5, x+20,y+6.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_rectangle(
        x+5.5, y+6.5, x+18.5, y+21,
        outline="black", width=1.7
    )

    canvas.create_line(
        x+9.5,y+10, x+9.5,y+17.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+14.5,y+10, x+14.5,y+17.5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )
