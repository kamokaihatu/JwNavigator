"""
JwNavigator Icon Library

Icon : 中心線
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_line(
        x+3,y+19, x+21,y+5,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND, dash=(5,2)
    )
