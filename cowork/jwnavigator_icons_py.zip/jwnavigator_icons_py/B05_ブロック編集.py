"""
JwNavigator Icon Library

Icon : ブロック編集
Size : 24x24
"""

import tkinter as tk

def draw(canvas, x=0, y=0):

    canvas.create_rectangle(
        x+2, y+2, x+17, y+17,
        outline="black", width=1.7, dash=(3,2)
    )

    canvas.create_rectangle(
        x+4.5, y+10.35, x+8.25, y+14.1,
        outline="black", width=1.7
    )

    canvas.create_rectangle(
        x+10.35, y+10.35, x+14.1, y+14.1,
        outline="black", width=1.7
    )

    canvas.create_rectangle(
        x+7.4, y+4.5, x+11.15, y+8.25,
        outline="black", width=1.7
    )

    canvas.create_line(
        x+14,y+21, x+19.25,y+15.75, x+21.5,y+13.5, x+22,y+15.75, x+19.75,y+18,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )

    canvas.create_line(
        x+17.5,y+15.25, x+20.5,y+18.25,
        width=1.7, capstyle=tk.ROUND, joinstyle=tk.ROUND
    )
